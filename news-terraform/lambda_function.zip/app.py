import json
import boto3
import os
from boto3.dynamodb.conditions import Key

# Ortam değişkeninden tablo adını al (Terraform gönderdi)
TABLE_NAME = os.environ['TABLE_NAME']
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    try:
        # Örnek veri (Eğer tablo boşsa React hata vermesin diye)
        # Gerçekte burada table.scan() yapacağız.
        response = table.scan()
        items = response.get('Items', [])
        
        # Eğer tablo boşsa sahte bir veri dönelim ki test yapabilelim
        if not items:
            items = [{
                "id": "1",
                "category": "Sistem",
                "title": "Terraform Başarıyla Çalıştı!",
                "summary": "Bu veri AWS Lambda üzerinden Terraform ile kurulan altyapıdan geliyor."
            }]

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps(items)
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Hata: {str(e)}")
        }
